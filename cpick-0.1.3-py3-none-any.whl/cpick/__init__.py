# Copyright (c) 2018, Toby Slight. All rights reserved.
# ISC License (ISCL) - see LICENSE file for details.

from .__main__ import pick
from .event import Event
name = "cpick"
