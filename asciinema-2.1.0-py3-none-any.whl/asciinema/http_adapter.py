class HTTPConnectionError(Exception):
    pass
