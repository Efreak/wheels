from .main import main as tdirstat
