# -*- coding: utf-8 -*-

__name__ = "gfzs"
__description__ = "Google Fuzzy Search"
__version__ = "0.2.3"
__copyright__ = "Copyright ©︎ 2021 yukihirop"
__url__ = "https://github.com/yukihirop/gfzs"
__author__ = "yukihirop"
__author_email__ = "te108186@gmail.com"
__license__ = "MIT"
