# -*- coding: utf-8 -*-

from gfzs.cli import main
