## 0.2.3

2021/02/02

- `[Fix bugs]` Bug about a page turning ([#21](https://github.com/yukihirop/gfzs/pull/21))
- `[New Features]` Output a Log ([#19](https://github.com/yukihirop/gfzs/pull/19))

Please see [milestone](https://github.com/yukihirop/gfzs/milestone/5)

## 0.2.2

2021/01/27

- `[Fix bugs]` Bug about a page turning ([#14](https://github.com/yukihirop/gfzs/issues/14))

Please see [milestone](https://github.com/yukihirop/gfzs/milestone/4)


## 0.2.1

2021/01/23

- `[Fix Bugs]` Score option is not reflected ([#8](https://github.com/yukihirop/gfzs/issues/8))

Please see [milestone](https://github.com/yukihirop/gfzs/milestone/2)

## 0.2.0

2021/01/23

- `[New Features]` Implement SubCommands ([#1](https://github.com/yukihirop/gfzs/issues/1))
  - `gfzs demo`
  - `gfzs valid`
- `[Improvement]` Changed to verify the setting before executing the main command ([#1](https://github.com/yukihirop/gfzs/issues/1))
- `[Fix Bugs]` Error if you press enter twice with Not Found displayed ([#5](https://github.com/yukihirop/gfzs/issues/5))

Please see [milestone](https://github.com/yukihirop/gfzs/milestone/3)

## 0.1.0

2021/01/22

- First Release
