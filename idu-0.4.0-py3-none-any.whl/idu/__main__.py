from idu import main

main()
