"""
Make sure `python -m pymux` works.
"""
from __future__ import unicode_literals
from .entry_points.run_pymux import run

if __name__ == '__main__':
    run()
