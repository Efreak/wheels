"""All the aria2p CLI commands."""
