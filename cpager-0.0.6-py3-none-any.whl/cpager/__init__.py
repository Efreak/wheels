from .cpager import pager

__all__ = ["pager"]
