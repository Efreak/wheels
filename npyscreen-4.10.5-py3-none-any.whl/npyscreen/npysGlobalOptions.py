DISABLE_ALL_COLORS = False
ASCII_ONLY         = False # See the safe_string function in wgwidget.  At the moment the encoding is not safe