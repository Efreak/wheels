import unittest


class TestMain(unittest.TestCase):
    def test_main(self):
        assert True
