"""Rendering routines."""


from eaf.render import Renderable
