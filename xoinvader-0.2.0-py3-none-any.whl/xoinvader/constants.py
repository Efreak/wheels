"""XOInvader constants."""


UTF_8 = "UTF-8"
"""UTF-8 encoding."""
