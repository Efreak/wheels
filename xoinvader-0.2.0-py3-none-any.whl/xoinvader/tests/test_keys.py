"""Test xoinvader.keys module."""

from xoinvader import keys


# pylint: disable=missing-docstring
def test_keys():
    assert keys
