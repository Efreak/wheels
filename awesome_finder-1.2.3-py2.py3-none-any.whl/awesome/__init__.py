"""
awesome-finder - A TUI based awesome curated list finder
"""
__version__ = '1.2.3'
__author__ = 'mingrammer'
__license__ = 'MIT'
