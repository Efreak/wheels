SINGLE = "s"
DOUBLE = "d"
KEYBOARD = "k"
