# Escape character
ESC = '\033'
# Control Sequence Introducer
CSI = ESC + '['
