from .core import append, in_new_path, need_shell_restart, prepend
from .utils import in_current_path

__version__ = '1.8.0'
