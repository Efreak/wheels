import sys
from .cli import userpath
sys.exit(userpath())
