class ViewLocation:
    IN_VIEW = 0
    ABOVE = 1
    BELOW = 2
    NOT_FOCUSED = 3


class BoxLine:
    TITLE = 0
    TOP = 1
    BOTTOM = 2
