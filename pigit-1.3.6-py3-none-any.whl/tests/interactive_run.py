import sys


sys.path.insert(0, ".")

from pigit.interaction import main

main()
